let popup=document.querySelector(".side-popup");
let humburger=document.querySelector(".fa-bars");
let mainContent=document.querySelector(".main-part");
let ai=document.querySelector(".ai-icon");




humburger.addEventListener("click",()=>{
    popup.style.width="70%";
    popup.style.opacity="1";
    popup.style.padding="10px 10px";
});


mainContent.addEventListener("click",()=>{
    if(popup.classList.contains("open")){
        popup.style.width="0%";
        popup.style.opacity="0";
        popup.style.padding="10px 0px";
    }
});


ai.addEventListener("click",()=>{
    window.location.href="Aichat.html";
});



document.querySelector(".options-two > div:nth-child(1)").addEventListener("click",()=>{
    window.location.href="home.html";
});


document.querySelector(".options-two > div:nth-child(3)").addEventListener("click",()=>{
    window.location.href="bio.html";
});

document.querySelector(".options-two > div:nth-child(4)").addEventListener("click",()=>{
    window.location.href="profile.html";
});