let cards = Array.from(document.querySelectorAll(".card"));

let answers = [2, 3, 2, 2, 2, 3, 2, 4];
let userAnswers = [];
let i = 0;
let switchQuestions = 1;
let score = 0;

cards.forEach(ele => {
    ele.addEventListener("click", (e) => {
        if (e.target.tagName == "INPUT") {
            userAnswers[i] = e.target.dataset.option;
            i++;
            if (userAnswers.length == 8) {
                for (let k = 0; k < answers.length; k++) {
                    if (answers[k] == userAnswers[k]) {
                        score++;
                    }
                }
                alert(`you scored ${score} out of 8`);
                window.location.href = "home.html";
            }
            cards.forEach(ele => {
                ele.style.transform = `translateX(-${switchQuestions}00%)`;
            });
            switchQuestions++;

        }
    });
});