from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from groq import Groq

app = Flask(__name__, static_folder="static", template_folder="templates")
CORS(app)

# === Groq client (replace with your API key) ===
api_key = "your_api_key_here"
client = Groq(api_key=api_key)

# === System prompt ===
system_prompt = {
    "role": "system",
    "content": (
        "You are a kind, respectful, and supportive financial assistant. "
        "Always keep replies short, clear, and polite."
    ),
}
chat_history = [system_prompt]

@app.route("/")
def home():
    return render_template("Aichat.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_msg = request.json.get("message", "").strip()
    if not user_msg:
        return jsonify({"reply": "⚠️ Please type something."})

    chat_history.append({"role": "user", "content": user_msg})

    response_text = ""
    try:
        stream = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=chat_history,
            max_tokens=512,
            temperature=1.0,
            stream=True,
        )
        for chunk in stream:
            content = chunk.choices[0].delta.content
            if content:
                response_text += content
    except Exception as e:
        return jsonify({"reply": f"⚠️ Error: {str(e)}"})

    chat_history.append({"role": "assistant", "content": response_text.strip()})
    return jsonify({"reply": response_text.strip()})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
